package com.example.jeremybrowneventtracking;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.Manifest;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import java.util.ArrayList;

public class EventListActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    EditText etEventName, etEventDate;
    Button btnAddEvent;
    EventAdapter adapter;
    DatabaseHelper db;

    private ActivityResultLauncher<String> requestSmsPermissionLauncher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event_list);

        recyclerView = findViewById(R.id.recyclerViewEvents);
        etEventName = findViewById(R.id.etEventName);
        etEventDate = findViewById(R.id.etEventDate);
        btnAddEvent = findViewById(R.id.btnAddEvent);

        db = new DatabaseHelper(this);
        ArrayList<Event> events = db.getAllEvents();

        adapter = new EventAdapter(events, db);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);

        // Initialize SMS permission launcher
        requestSmsPermissionLauncher = registerForActivityResult(
                new ActivityResultContracts.RequestPermission(),
                isGranted -> {
                    if (isGranted) {
                        Toast.makeText(this, "SMS permission granted", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(this, "SMS permission denied. App will continue without SMS.", Toast.LENGTH_SHORT).show();
                    }
                }
        );

        // Request SMS permission after login
        requestSmsPermissionIfNeeded();

        // Add event button listener
        btnAddEvent.setOnClickListener(v -> {
            String name = etEventName.getText().toString().trim();
            String date = etEventDate.getText().toString().trim();
            if (name.isEmpty() || date.isEmpty()) {
                Toast.makeText(this, "Enter event name and date", Toast.LENGTH_SHORT).show();
                return;
            }
            if (db.addEvent(name, date)) {
                events.clear();
                events.addAll(db.getAllEvents());
                adapter.notifyDataSetChanged();
                etEventName.setText("");
                etEventDate.setText("");

                // Example SMS notification (replace with actual number)
                sendSms("+1234567890", "New event added: " + name + " on " + date);

            } else {
                Toast.makeText(this, "Failed to add event", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void requestSmsPermissionIfNeeded() {
        if (checkSelfPermission(Manifest.permission.SEND_SMS)
                != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestSmsPermissionLauncher.launch(Manifest.permission.SEND_SMS);
        }
    }

    private void sendSms(String phoneNumber, String message) {
        if (checkSelfPermission(Manifest.permission.SEND_SMS)
                == android.content.pm.PackageManager.PERMISSION_GRANTED) {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
            Toast.makeText(this, "SMS sent!", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Cannot send SMS. Permission not granted.", Toast.LENGTH_SHORT).show();
        }
    }
}

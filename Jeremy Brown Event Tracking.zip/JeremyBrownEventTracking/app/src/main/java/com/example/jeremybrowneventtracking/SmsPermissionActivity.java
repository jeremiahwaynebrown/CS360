package com.example.jeremybrowneventtracking;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

public class SmsPermissionActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms_permission);

        // Find buttons
        Button btnGrant = findViewById(R.id.btnGrant);
        Button btnDeny = findViewById(R.id.btnDeny);

        // Grant button clicked
        btnGrant.setOnClickListener(v -> {
            Toast.makeText(this, "SMS permission granted (simulated)", Toast.LENGTH_SHORT).show();
            goToEventList();
        });

        // Deny button clicked
        btnDeny.setOnClickListener(v -> {
            Toast.makeText(this, "SMS permission denied (simulated)", Toast.LENGTH_SHORT).show();
            goToEventList();
        });
    }

    // Navigate to EventListActivity
    private void goToEventList() {
        Intent intent = new Intent(SmsPermissionActivity.this, EventListActivity.class);
        startActivity(intent);
        finish(); // optional: remove this activity from back stack
    }
}
